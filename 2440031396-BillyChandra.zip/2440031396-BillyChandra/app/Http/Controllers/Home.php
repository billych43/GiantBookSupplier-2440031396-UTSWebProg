<?php

namespace App\Http\Controllers;

use App\Models\Books;
use App\Models\Categories;
use App\Models\Publishers;
use Illuminate\Http\Request;

class Home extends Controller
{
    public function index()
    {
        $data = [
            'categories'=>Categories::All(),
            'books'=>Books::All(),
        ];
        return view('home',$data);
    }
    public function booksdetail($id)
    {
        $buku = Books::where('id',$id)->first();
        $data = [
            'categories'=>Categories::All(),
            'buku'=>$buku,
        ];
        return view('booksdetail',$data);
    }
    public function categorydetail($id)
    {
        $kategori = Categories::where('id',$id)->first();
        $data = [
            'categories'=>Categories::All(),
            'category'=>$kategori,
        ];
        return view('categorydetail',$data);
    }
    public function publisherdetail($id)
    {
        $publisher = Publishers::where('id',$id)->first();
        $data = [
            'categories'=>Categories::All(),
            'publisher'=>$publisher,
        ];
        return view('publisherdetail',$data);
    }
    public function contact()
    {
        $data = [
            'categories'=>Categories::All(),
        ];
        return view('contact',$data);
    }
    public function publisher()
    {
        $data = [
            'categories'=>Categories::All(),
            'publishers'=>Publishers::All(),
        ];
        return view('publisher',$data);
    }
}
