<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Books extends Model
{
    use HasFactory;
    public function publisher()
    {
        return $this->belongsTo(Publishers::class,'publisher_id');
    }
    public function categoryRelated()
    {
        return $this->hasMany(BookCategories::class,'book_id');
    }
}
