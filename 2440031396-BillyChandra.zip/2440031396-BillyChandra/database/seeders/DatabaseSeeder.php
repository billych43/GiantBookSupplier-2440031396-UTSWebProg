<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // book id 1 punya 2 kategori
        DB::table('book_categories')->insert([
            'book_id' => 1,
            'category_id' => 1,
        ]);
        DB::table('book_categories')->insert([
            'book_id' => 1,
            'category_id' => 2,
        ]);

        // book id 2 punya 1 kategori
        DB::table('book_categories')->insert([
            'book_id' => 2,
            'category_id' => 1,
        ]);

        // book id 3 punya 4 kategori
        DB::table('book_categories')->insert([
            'book_id' => 3,
            'category_id' => 1,
        ]);
        DB::table('book_categories')->insert([
            'book_id' => 3,
            'category_id' => 2,
        ]);
        DB::table('book_categories')->insert([
            'book_id' => 3,
            'category_id' => 3,
        ]);
        DB::table('book_categories')->insert([
            'book_id' => 3,
            'category_id' => 4,
        ]);

        // book id 4 punya 4 kategori
        DB::table('book_categories')->insert([
            'book_id' => 4,
            'category_id' => 1,
        ]);
        DB::table('book_categories')->insert([
            'book_id' => 4,
            'category_id' => 2,
        ]);
        DB::table('book_categories')->insert([
            'book_id' => 4,
            'category_id' => 3,
        ]);

        DB::table('books')->insert([
            'publisher_id' => 1,
            'title' => "Sisa Rasa",
            'author' => "Mahalini",
            'year' => 2000,
            'synopsis' => "bla bla bla bla blla",
            'image' => "default.jpg",
        ]);
        DB::table('books')->insert([
            'publisher_id' => 4,
            'title' => "Dibuat Dengan Luka",
            'author' => "Doni, Kecepit",
            'year' => 2012,
            'synopsis' => "bla bla bla bla blla",
            'image' => "default.jpg",
        ]);
        DB::table('books')->insert([
            'publisher_id' => 2,
            'title' => "Teman Naga-ku",
            'author' => "Didik, Moha",
            'year' => 2001,
            'synopsis' => "bla bla bla bla blla",
            'image' => "default.jpg",
        ]);
        DB::table('books')->insert([
            'publisher_id' => 3,
            'title' => "Petualangan Perempuan",
            'author' => "Saya, Ayaya",
            'year' => 1992,
            'synopsis' => "bla bla bla bla blla",
            'image' => "default.jpg",
        ]);

        DB::table('categories')->insert([
            'name' => "Drama",
        ]);
        DB::table('categories')->insert([
            'name' => "Petualangan",
        ]);
        DB::table('categories')->insert([
            'name' => "Romansa",
        ]);
        DB::table('categories')->insert([
            'name' => "Fantasi",
        ]);

        DB::table('publishers')->insert([
            "name" => "Studio Ghibli",
            "phone" => "15746699542",
            "email" => "ghibli@jp.jp",
            "address" => "hanoi, thailand",
            'image' => "default.jpg",
        ]);
        DB::table('publishers')->insert([
            "name" => "TOEI",
            "phone" => "13238436325",
            "email" => "toei@jp.jp",
            "address" => "honda prefecture, 112",
            'image' => "default.jpg",
        ]);
        DB::table('publishers')->insert([
            "name" => "PA. Works",
            "phone" => "18233669547",
            "email" => "paworks@jp.jp",
            "address" => "kawasaki prefecture, 112",
            'image' => "default.jpg",
        ]);
        DB::table('publishers')->insert([
            "name" => "Mizan Pustaka",
            "phone" => "089522798664",
            "email" => "mipus@id.id",
            "address" => "Jl. ada deh no 223",
            'image' => "default.jpg",
        ]);
    }
}
