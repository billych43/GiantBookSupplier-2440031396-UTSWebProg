@extends('layouts.main')

@section('navbar')
    @include('partial')
@endsection
@section('content')
<div class="container">
    <div class="d-flex justify-content-between align-items-baseline"><div class="fs-2">Book list</div></div>
    <div class="bg-warning row py-3 px-5 rounded mt-2">
        @foreach ($books as $book)
        <div class="col-3 px-2">
            <div class="card bg-dark text-light">
                <img src="{{asset("/books/{$book->image}")}}" class="card-img-top" alt="{{$book->image}}">
                <div class="card-body">
                  <h5 class="card-title">{{$book->title}}</h5>
                  <p class="m-0">by</p>
                  <p class="card-text text-muted">{{$book->author}}</p>
                  <a href="/book/{{$book->id}}" class="btn btn-outline-light">Selengkapnya</a>
                </div>
            </div>
        </div>
        @endforeach
    </div>
</div>
@endsection
