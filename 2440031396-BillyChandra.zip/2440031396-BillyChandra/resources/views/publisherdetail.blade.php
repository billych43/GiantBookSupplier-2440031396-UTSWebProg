@extends('layouts.main')

@section('navbar')
    @include('partial')
@endsection
@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-2">
            <img style="width: 100%" src="{{asset("/publisher/{$publisher->image}")}}" class="border rounded" alt="{{$publisher->image}}">
        </div>
        <div class="col-md-10">
            <div class="ms-4">
                <h2 class="fs-1">{{$publisher->name}}</h2>
                <div class="">Email: {{$publisher->email}} - Phone: {{$publisher->phone}}</div>
                <div class="">Alamat: {{$publisher->address}}</div>
            </div>

        </div>
    </div>
    <div class="bg-warning py-3 px-5 rounded mt-2">
        <div class="bg-dark rounded px-2 w-50">
            <h3 class="text-light fs-2">Books</h3>
        </div>
        <div class="row">
            @foreach ($publisher->books as $book)
            <div class="col-3 px-2">
                <div class="card bg-dark text-light">
                    <img src="{{asset("/books/{$book->image}")}}" class="card-img-top" alt="{{$book->image}}">
                    <div class="card-body">
                    <h5 class="card-title">{{$book->title}}</h5>
                    <p class="card-text text-muted">{{$book->author}}</p>
                    <a href="/book/{{$book->id}}" class="btn btn-outline-light">Selengkapnya</a>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</div>
@endsection
