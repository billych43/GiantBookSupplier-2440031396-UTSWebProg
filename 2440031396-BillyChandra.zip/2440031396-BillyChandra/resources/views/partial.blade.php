<nav class="navbar navbar-expand-lg bg-light" style="z-index: 1">
    <div class="container-fluid">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-center" id="navbarSupportedContent">
            <ul class="navbar-nav">
                <li class="nav-item">
                  <a class="nav-link{{Request::is('/')?' active':''}}" aria-current="page" href="/">Home</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle{{Request::is('category*')?' active':''}}" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                      Kategori
                    </a>
                    <ul class="dropdown-menu">
                        @foreach ($categories as $category)
                        <li><a class="dropdown-item{{Request::is("category/{$category->id}")?' active':''}}" href="/category/{{$category->id}}">{{$category->name}}</a></li>
                        @endforeach
                    </ul>
                </li>
                <li class="nav-item">
                  <a class="nav-link{{Request::is('penerbit*')?' active':''}}" href="/penerbit">Publisher</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link{{Request::is('contact*')?' active':''}}" href="/contact">Kontak</a>
                </li>
              </ul>
        </div>
    </div>
</nav>
