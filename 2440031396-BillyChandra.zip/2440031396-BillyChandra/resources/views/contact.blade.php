@extends('layouts.main')

@section('navbar')
    @include('partial')
@endsection
@section('content')
<div class="container mb-5">
    <div class="fs-2">Giant Books</div>
    <div class="bg-warning py-3 px-5 rounded mt-2">
        <div class="row mb-3">
            <div class="col-4 px-2">
                <div class="card bg-dark text-light">
                    <div class="card-body text-center">
                        <h5 class="card-title">Open Daily</h5>
                        <p class="card-text">09.00 - 18.00</p>
                    </div>
                </div>
            </div>
            <div class="col-4 px-2">
                <div class="card bg-dark text-light">
                    <div class="card-body text-center">
                        <h5 class="card-title">Phone</h5>
                        <p class="card-text">0561 - 760406</p>
                    </div>
                </div>
            </div>
            <div class="col-4 px-2">
                <div class="card bg-dark text-light">
                    <div class="card-body text-center">
                        <h5 class="card-title">Email</h5>
                        <p class="card-text">giantbook@gmail.com</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12 px-2">
                <div class="card bg-dark text-light">
                    <div class="card-body text-center">
                        <h5 class="card-title">Alamat</h5>
                        <p class="card-text">
                            Jalan Pademangan 2,<br>Gang 15, No 43<br>Jakarta Utara<br>Indonesia
                        </p>
                    </div>
                </div>
            </div>
        </div>
</div>
@endsection
