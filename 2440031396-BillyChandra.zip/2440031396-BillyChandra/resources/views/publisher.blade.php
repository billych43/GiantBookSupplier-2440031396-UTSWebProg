@extends('layouts.main')

@section('navbar')
    @include('partial')
@endsection
@section('content')
<div class="container">
    <div class="fs-2">Publisher</div>
    <div class="bg-warning row py-3 px-5 rounded mt-2">
        @foreach ($publishers as $publisher)
        <div class="col-3 px-2">
            <a href="/penerbit/{{$publisher->id}}" class="btn btn-light">
                <div class="card">
                    <img src="{{asset("/publisher/{$publisher->image}")}}" class="card-img-top" alt="{{$publisher->image}}">
                    <div class="card-body text-center">
                      <h5 class="card-title text-center">{{$publisher->name}}</h5>
                    </div>
                </div>
            </a>
        </div>
        @endforeach
    </div>
</div>
@endsection
