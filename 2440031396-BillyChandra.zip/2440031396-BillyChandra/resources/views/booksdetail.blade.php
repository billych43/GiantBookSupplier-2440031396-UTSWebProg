@extends('layouts.main')

@section('navbar')
    @include('partial')
@endsection
@section('content')
<div class="container">
    <div class="bg-dark text-light py-3 px-5 rounded mt-2">
        <div class="fs-2">Detail Buku</div>
        <div class="row bg-light px-2 py-4 rounded align-items-center">
            <div class="col-6">
                <img src="{{asset("/books/{$buku->image}")}}" class="img-thumbnail" alt="{{$buku->image}}">
            </div>
            <div class="col-6">
                <table class="table table-secondary">
                    <tbody>
                        <tr>
                            <td>Judul</td>
                            <td>{{$buku->title}}</td>
                        </tr>
                        <tr>
                            <td>Author</td>
                            <td>{{$buku->author}}</td>
                        </tr>
                        <tr>
                            <td>Publisher</td>
                            <td>
                                <a href="/penerbit/{{$buku->publisher->id}}" class='me-1 btn btn-sm btn-secondary'>{{$buku->publisher->name}}</a>
                            </td>
                        </tr>
                        <tr>
                            <td>Kategori</td>
                            <td>
                                @foreach($buku->categoryrelated as $item)
                                <a href="/category/{{$item->category_id}}" class='me-1 btn btn-sm btn-danger'>{{$item->category->name}}</a>
                                @endforeach
                            </td>
                        </tr>
                        <tr>
                            <td>Synopsis</td>
                            <td>{{$buku->synopsis}}</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
@endsection
