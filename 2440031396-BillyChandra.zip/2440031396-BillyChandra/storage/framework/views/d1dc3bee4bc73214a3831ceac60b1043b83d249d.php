<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make('partial', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-2">
            <img style="width: 100%" src="<?php echo e(asset("/publisher/{$publisher->image}")); ?>" class="border rounded" alt="<?php echo e($publisher->image); ?>">
        </div>
        <div class="col-md-10">
            <div class="ms-4">
                <h2 class="fs-1"><?php echo e($publisher->name); ?></h2>
                <div class="">Email: <?php echo e($publisher->email); ?> - Phone: <?php echo e($publisher->phone); ?></div>
                <div class="">Alamat: <?php echo e($publisher->address); ?></div>
            </div>

        </div>
    </div>
    <div class="bg-warning py-3 px-5 rounded mt-2">
        <div class="bg-dark rounded px-2 w-50">
            <h3 class="text-light fs-2">Books</h3>
        </div>
        <div class="row">
            <?php $__currentLoopData = $publisher->books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-3 px-2">
                <div class="card bg-dark text-light">
                    <img src="<?php echo e(asset("/books/{$book->image}")); ?>" class="card-img-top" alt="<?php echo e($book->image); ?>">
                    <div class="card-body">
                    <h5 class="card-title"><?php echo e($book->title); ?></h5>
                    <p class="card-text text-muted"><?php echo e($book->author); ?></p>
                    <a href="/book/<?php echo e($book->id); ?>" class="btn btn-outline-light">Selengkapnya</a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\semester 5\UTS\WEBPROG\2440031396-BillyChandra\resources\views/publisherdetail.blade.php ENDPATH**/ ?>