<nav class="navbar navbar-expand-lg bg-light" style="z-index: 1">
    <div class="container-fluid">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-center" id="navbarSupportedContent">
            <ul class="navbar-nav">
                <li class="nav-item">
                  <a class="nav-link<?php echo e(Request::is('/')?' active':''); ?>" aria-current="page" href="/">Home</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle<?php echo e(Request::is('category*')?' active':''); ?>" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                      Kategori
                    </a>
                    <ul class="dropdown-menu">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a class="dropdown-item<?php echo e(Request::is("category/{$category->id}")?' active':''); ?>" href="/category/<?php echo e($category->id); ?>"><?php echo e($category->name); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </li>
                <li class="nav-item">
                  <a class="nav-link<?php echo e(Request::is('penerbit*')?' active':''); ?>" href="/penerbit">Publisher</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link<?php echo e(Request::is('contact*')?' active':''); ?>" href="/contact">Kontak</a>
                </li>
              </ul>
        </div>
    </div>
</nav>
<?php /**PATH D:\semester 5\UTS\WEBPROG\2440031396-BillyChandra\resources\views/partial.blade.php ENDPATH**/ ?>