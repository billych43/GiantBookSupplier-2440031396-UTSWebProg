<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make('partial', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="bg-dark text-light py-3 px-5 rounded mt-2">
        <div class="fs-2">Detail Buku</div>
        <div class="row bg-light px-2 py-4 rounded align-items-center">
            <div class="col-6">
                <img src="<?php echo e(asset("/books/{$buku->image}")); ?>" class="img-thumbnail" alt="<?php echo e($buku->image); ?>">
            </div>
            <div class="col-6">
                <table class="table table-secondary">
                    <tbody>
                        <tr>
                            <td>Judul</td>
                            <td><?php echo e($buku->title); ?></td>
                        </tr>
                        <tr>
                            <td>Author</td>
                            <td><?php echo e($buku->author); ?></td>
                        </tr>
                        <tr>
                            <td>Publisher</td>
                            <td>
                                <a href="/penerbit/<?php echo e($buku->publisher->id); ?>" class='me-1 btn btn-sm btn-secondary'><?php echo e($buku->publisher->name); ?></a>
                            </td>
                        </tr>
                        <tr>
                            <td>Kategori</td>
                            <td>
                                <?php $__currentLoopData = $buku->categoryrelated; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="/category/<?php echo e($item->category_id); ?>" class='me-1 btn btn-sm btn-danger'><?php echo e($item->category->name); ?></a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                        </tr>
                        <tr>
                            <td>Synopsis</td>
                            <td><?php echo e($buku->synopsis); ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\semester 5\UTS\WEBPROG\2440031396-BillyChandra\resources\views/booksdetail.blade.php ENDPATH**/ ?>