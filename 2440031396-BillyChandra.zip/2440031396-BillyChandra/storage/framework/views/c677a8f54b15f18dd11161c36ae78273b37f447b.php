<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make('partial', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="fs-2">Publisher</div>
    <div class="bg-warning row py-3 px-5 rounded mt-2">
        <?php $__currentLoopData = $publishers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $publisher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-3 px-2">
            <a href="/penerbit/<?php echo e($publisher->id); ?>" class="btn btn-light">
                <div class="card">
                    <img src="<?php echo e(asset("/publisher/{$publisher->image}")); ?>" class="card-img-top" alt="<?php echo e($publisher->image); ?>">
                    <div class="card-body text-center">
                      <h5 class="card-title text-center"><?php echo e($publisher->name); ?></h5>
                    </div>
                </div>
            </a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\semester 5\UTS\WEBPROG\2440031396-BillyChandra\resources\views/publisher.blade.php ENDPATH**/ ?>