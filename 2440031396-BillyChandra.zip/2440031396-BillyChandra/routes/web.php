<?php
use App\Http\Controllers\Home;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::controller(Home::class)->group(function(){
    Route::get('/', 'index');
    Route::get('/book/{id}', 'booksdetail');
    Route::get('/category/{id}', 'categorydetail');
    Route::get('/penerbit', 'publisher');
    Route::get('/penerbit/{id}', 'publisherdetail');
    Route::get('/contact', 'contact');
});
